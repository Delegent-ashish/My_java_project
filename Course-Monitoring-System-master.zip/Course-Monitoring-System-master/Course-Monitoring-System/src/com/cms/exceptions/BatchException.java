package com.cms.exceptions;

public class BatchException extends Exception{

	public BatchException() {
		// TODO Auto-generated constructor stub
	}

	public BatchException(String message) {
		super(message);
	}

}
