package com.cms.exceptions;

public class FacultyException extends Exception{
	
	public FacultyException() {
		// TODO Auto-generated constructor stub
	}
	
	public FacultyException(String message) {
		super(message);
	}

}
