package com.cms.exceptions;

public class CoursePlanException extends Exception {

	public CoursePlanException() {
		// TODO Auto-generated constructor stub
	}

	public CoursePlanException(String message) {
		super(message);
	}

}
